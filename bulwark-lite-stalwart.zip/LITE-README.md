# Bulwark Lite 1.21.3 (local) for Stalwart

Bulwark Webmail as a Stalwart `Application`: Stalwart downloads this zip,
serves it under a path of its own HTTP listener, and the webmail talks to the
same server's JMAP, login and token endpoints. There is nothing to configure:
no server URL, no CORS, no second web server.

Build: 1.21.3-local-tov2v1
Locales: ar, ca, cs, da, de, el, en, es, et, fa, fr, he, hu, it, ja, ko, lv, mn, nb, nl, nn, pl, pt, ro, ru, sk, th, tr, uk, vi, zh, zh-TW
Requires: Stalwart 0.16.6 or later (0.16.19 for `oauthClientId`), or 1.0.

## Install

An administrator creates one Application and then runs the `UpdateApps`
action: Stalwart only downloads and mounts Applications on that action or at
startup, so creating the object alone serves nothing. Permissions:
`sysApplicationCreate` (plus `sysApplicationGet`/`sysApplicationQuery` to
list, `sysApplicationUpdate` to change and `sysApplicationDestroy` to remove
it) and `actionUpdateApps`. Any of these is equivalent:

- Web admin: **Settings > Web Applications > Create**, description
  `Bulwark Webmail`, resource URL `https://github.com/bulwarkmail/webmail/releases/download/1.21.3/bulwark-lite-stalwart.zip`, URL prefix `/webmail`; then run
  **Actions > Update applications** (or restart Stalwart).
- CLI:

  ```bash
  stalwart-cli create Application \
    --field description='Bulwark Webmail' \
    --field resourceUrl='https://github.com/bulwarkmail/webmail/releases/download/1.21.3/bulwark-lite-stalwart.zip' \
    --field 'urlPrefix={"/webmail":true}'
  stalwart-cli create Action/UpdateApps
  ```

- JMAP (`urn:stalwart:jmap`), as an administrator:

  ```json
  {
    "using": ["urn:ietf:params:jmap:core", "urn:stalwart:jmap"],
    "methodCalls": [
      ["x:Application/set", { "create": { "webmail": {
        "description": "Bulwark Webmail",
        "resourceUrl": "https://github.com/bulwarkmail/webmail/releases/download/1.21.3/bulwark-lite-stalwart.zip",
        "urlPrefix": { "/webmail": true }
      } } }, "0"],
      ["x:Action/set", { "create": { "u": { "@type": "UpdateApps" } } }, "1"]
    ]
  }
  ```

Then open `https://<your stalwart host>/webmail/` and sign in with a mail
account.

## Mount prefix

`urlPrefix` is matched against the first path segment only (`/webmail`,
not `/apps/webmail`), and several prefixes may serve the same bundle. The
bundle works under any prefix: it reads it from the `<base href>` Stalwart
writes into index.html. Stalwart routes these first segments itself, so an
Application mounted there is never reached: `jmap`, `dav`, `.well-known`,
`auth`, `api`, `scim`, `mail`, `calendar`, `autodiscover`, `login`,
`device`, `metrics`, `healthz`, `logo`, `form`, `robots.txt`, and the web
admin's own `admin` and `account`.

## Updates

The resource URL above names one release, so what Stalwart serves only
changes when you change it: to update, point `resourceUrl` at the new
release's tag and run `UpdateApps`, which always downloads again.

What a failed download does depends on the Stalwart version. On 0.16.23 the
running bundle stays online, as on later 0.16 releases and on 1.0.
Older 0.16 releases and the 1.0 pre-releases
unmount the Application and drop the cached copy. The next restart,
`UpdateApps` or reload of the Applications (the other nodes of a cluster
reload them after `UpdateApps`) downloads `resourceUrl` again and mounts the
bundle once that works. On every version, a restart after the cached copy
has expired, with `resourceUrl` unreachable, leaves the Application
unmounted. So check that `resourceUrl` downloads before running
`UpdateApps` or restarting. Every release also carries
`bulwark-lite-stalwart.zip.sha256`; check a download with
`sha256sum -c bulwark-lite-stalwart.zip.sha256` before you switch.

The bundle runs as script on your Stalwart origin, next to the web admin.
Stalwart checks no hash or signature when it downloads, so a floating URL
such as `https://github.com/bulwarkmail/webmail/releases/latest/download/bulwark-lite-stalwart.zip` would run whatever the newest release holds, at the
next restart or `UpdateApps` after `autoUpdateFrequency` (on 1.0
`autoUpdateInterval`, default 90 days). Use it only if you accept that in exchange for automatic updates.

Open tabs move to the new build on their next navigation (one full page
load); a freshly opened tab gets it immediately. Nothing stays stuck on old
files although Stalwart sends a year-long cache header for every file but
index.html: every file the app fetches without a content hash carries the
build id.

## Sign-in

Passwords (and TOTP codes) go to Stalwart's `/api/auth` and are exchanged at
`/auth/token` for an access token and a refresh token, all on the same
origin. "Remember me" keeps the refresh token in localStorage, otherwise it
lives with the tab. Either way it is stored sealed (see Security below).

Serve Stalwart over HTTPS. On a plain `http://` address other than
`localhost`, browsers withhold the Web Crypto API this sign-in needs, so the
webmail falls back to a password sign-in that lasts only as long as the tab:
"Remember me" has no effect and single sign-on does not work.

The OAuth client id is the Application's `oauthClientId` (Stalwart writes it
into index.html) or `bulwark-webmail` when that field is empty. If your
server requires registered OAuth clients, register that client id with the
redirect URI `https://<your stalwart host>/<prefix>/` (for example
`https://mail.example.com/webmail/`), once per prefix you mount.

Stalwart 1.0 always requires registered clients. When it knows no client by
the default name, the app registers one of its own and signs in with that:
mail, contacts, calendars and files work, but the account's Stalwart
settings (password, two-factor authentication, app passwords) do not, since
1.0 only lets a first-party client manage those. For them, create an
`OAuthClient` with client id `bulwark-webmail` (or the `oauthClientId`
you set), `firstParty` on, and the redirect URI above.

### Single sign-on (OpenID Connect)

An account whose directory is an external OpenID provider has no password
Stalwart could check, so the form above cannot sign it in. The app asks
Stalwart who signs an address in (`/api/discover/<address>`, the lookup
Stalwart's own web admin uses): for such an account the password field gives
way to **Sign in with SSO**, which sends the user to the provider
(authorization code with PKCE) and redeems the code in the browser. Accounts
Stalwart authenticates itself keep the password form.

At the provider, register a **public** client (no secret, PKCE `S256`) with:

- the client id you put into the Application's `oauthClientId` (or
  `bulwark-webmail` if you leave that empty);
- the redirect URI `https://<your stalwart host>/<prefix>/oauth/callback`
  (for example `https://mail.example.com/webmail/oauth/callback`). It names
  no language, so one URI per prefix covers every locale;
- CORS on its token endpoint for `https://<your stalwart host>`, because the
  browser redeems and renews tokens there directly. Stalwart's web admin needs
  the same, so a provider already set up for it only needs the extra client.

Setting `oauthClientId` also shows **Sign in with SSO** next to the password
form for accounts Stalwart authenticates itself; that route goes through
Stalwart's own login page and needs the `.../oauth/callback` URI registered
as well if your server requires registered clients. Per-domain directories
are a Stalwart Enterprise feature; the community edition has one directory
for every account.

## Security

Stalwart sends no security headers for an Application, so the bundle
carries its own Content-Security-Policy: scripts load from this origin
only, and no inline script runs but the entry document's own. The entry
also refuses to run inside another site's frame.

The webmail shares its origin with everything else this Stalwart serves,
including every file users keep in its file storage (`/dav/`) and every
attachment the download endpoint returns (`/jmap/download/`). Stalwart
serves those with the type they were stored with, so an HTML file there
opens as a page on the webmail's origin. Sign-in tokens are stored sealed
with a key the browser keeps in IndexedDB and lets no script copy out: a
script that reads web storage finds no token, and what is stored is of no
use outside the browser profile. A script running on the origin can still
use that key while the browser holds it. So put a reverse proxy in front of
Stalwart that sends these headers for `/dav/` and `/jmap/download/`:

```
Content-Security-Policy: sandbox
X-Content-Type-Options: nosniff
```

For the mount path itself the proxy may add `X-Frame-Options: SAMEORIGIN`,
`X-Content-Type-Options: nosniff` and `Referrer-Policy`. A
Content-Security-Policy header there must not limit `script-src`: it would
refuse the entry document's own script.

On a server several organisations share, the static zip on a host name of
its own is the safer choice: there the webmail's origin serves nothing but
the webmail.

## Branding and settings

The bundle is read-only once Stalwart has unpacked it. To change the app
name, turn "remember me" off or build any other variant, run the
**Build Static Lite** workflow (or, in a throwaway checkout,
`npm run build:lite -- --in-place --target=stalwart`) with your settings, publish the resulting `bulwark-lite-stalwart.zip` at a URL
you control, and use that URL as `resourceUrl`. `config.json` and
`policy.json` inside the zip take the same keys as in the static-host build.

## Differences from the static-host zip

- One entry document (`index.html`) boots every route: Stalwart has no
  rewrite rules and answers every unknown path with it.
- No `_redirects`, `_headers`, nginx/Caddy examples or `404.html`.
- `config.json` defaults to the serving Stalwart and hides the server field;
  no CORS settings are needed.
- The mount prefix is detected at runtime instead of being baked in.
- `manifest.json` replaces `manifest.webmanifest` (Stalwart would serve the
  latter as `application/octet-stream`).

Everything else the static-host build leaves out (admin console, plugins,
settings sync, web push, office editing, ICS subscriptions) is also missing
here. Single sign-on is the exception: it works in this bundle, as described
above.
